# Trust Chrome Extension
A client interface for issuing Trust
